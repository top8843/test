/**
 *
 */
Ext.define('Ext.layout.VBox', {
    extend: 'Ext.layout.FlexBox',

    alias: 'layout.vbox',

    config: {
        orient: 'vertical'
    }
});
